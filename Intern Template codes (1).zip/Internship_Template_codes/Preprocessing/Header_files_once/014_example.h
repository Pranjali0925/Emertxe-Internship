#ifndef EXAMPLE_013_H
#define EXAMPLE_013_H

struct UserInfo
{
        int id; 
	    char name[30];
};

#endif
