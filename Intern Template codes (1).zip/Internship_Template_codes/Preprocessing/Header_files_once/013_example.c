#include "014_example.h"
#include "014_example.h"

int main()
{
    struct UserInfo p = {420, "Tingu"};

    return 0;
}
