#include <stdio.h>

extern int num;

int func_2()
{
	printf("num is %d from file3\n", num);

	return 0;
}
