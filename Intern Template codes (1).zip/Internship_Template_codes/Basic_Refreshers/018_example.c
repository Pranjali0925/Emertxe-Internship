#include <stdio.h>

int main()
{
	int num = 5;
	

	printf("%u:%u:%u\n", sizeof(int), sizeof num, sizeof (5));

	return 0;
}
