#include <stdio.h>

int main()
{
		int iter = 0;

		for (iter = 0 ; iter < 10; iter++ )
		{
				printf("Looped %d times\n", iter);
		}
		return 0;
}
