#include <stdio.h>

int main()
{
	int num;

	num = 7 - 4 * 3 / 2 + 5;

	printf("Result is %d\n", num);

	return 0;
}
