#include <stdio.h>

int main()
{
	int x;
	int *ptr;

	x = 5;
	ptr = 5;

	return 0;
}
