#include <stdio.h>

int main()
{
	char *str = "Hello";

	printf("%zu\n", sizeof(str));

	return 0;
}
